pumilioR
========

R package to query and get data out of a Pumilio system.
